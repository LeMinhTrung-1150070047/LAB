package com.example.lab7;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadService extends Service {
    private static final String CHANNEL_ID = "DownloadChannel";
    private static final int NOTIFICATION_ID = 1;

    private boolean isPaused = false;
    private boolean isCancelled = false;
    private Thread downloadThread;
    private String downloadUrl;
    private NotificationManager notificationManager;
    private long downloadedBytes = 0;
    private long totalBytes = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();

            if (action != null) {
                switch (action) {
                    case "START_DOWNLOAD":
                        downloadUrl = intent.getStringExtra("url");
                        startDownload();
                        break;
                    case "com.example.downloadmanager.ACTION_PAUSE":
                        pauseDownload();
                        break;
                    case "com.example.downloadmanager.ACTION_RESUME":
                        resumeDownload();
                        break;
                    case "com.example.downloadmanager.ACTION_CANCEL":
                        cancelDownload();
                        break;
                }
            }
        }
        return START_STICKY;
    }

    private void startDownload() {
        isPaused = false;
        isCancelled = false;
        downloadedBytes = 0;

        startForeground(NOTIFICATION_ID, createNotification("Downloading...", 0, false));

        downloadThread = new Thread(() -> {
            try {
                URL url = new URL(downloadUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setDoInput(true);

                if (downloadedBytes > 0) {
                    connection.setRequestProperty("Range", "bytes=" + downloadedBytes + "-");
                }

                connection.connect();

                totalBytes = connection.getContentLength();
                if (downloadedBytes > 0) {
                    totalBytes += downloadedBytes;
                }

                // Tạo tên file từ URL
                String fileName = downloadUrl.substring(downloadUrl.lastIndexOf('/') + 1);
                if (fileName.isEmpty()) {
                    fileName = "downloaded_file";
                }

                File file = new File(getFilesDir(), fileName);
                FileOutputStream fos = new FileOutputStream(file, downloadedBytes > 0);
                InputStream is = connection.getInputStream();

                byte[] buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = is.read(buffer)) != -1) {
                    if (isCancelled) {
                        fos.close();
                        is.close();
                        file.delete();
                        updateStatus("Download cancelled");
                        stopForeground(true);
                        stopSelf();
                        return;
                    }

                    while (isPaused && !isCancelled) {
                        Thread.sleep(100);
                    }

                    if (isCancelled) {
                        fos.close();
                        is.close();
                        file.delete();
                        updateStatus("Download cancelled");
                        stopForeground(true);
                        stopSelf();
                        return;
                    }

                    fos.write(buffer, 0, bytesRead);
                    downloadedBytes += bytesRead;

                    int progress = (int) ((downloadedBytes * 100) / totalBytes);
                    updateNotification("Downloading...", progress, false);
                    updateStatus("Downloading: " + progress + "%");
                }

                fos.close();
                is.close();
                connection.disconnect();

                // Download hoàn tất
                updateNotification("Download Complete!", 100, true);
                updateStatus("Download completed: " + file.getAbsolutePath());

                Thread.sleep(2000);
                stopForeground(true);
                stopSelf();

            } catch (Exception e) {
                e.printStackTrace();
                updateNotification("Download Failed", 0, true);
                updateStatus("Download failed: " + e.getMessage());
                stopForeground(true);
                stopSelf();
            }
        });

        downloadThread.start();
    }

    private void pauseDownload() {
        isPaused = true;
        updateNotification("Download Paused",
                (int) ((downloadedBytes * 100) / totalBytes), false);
        updateStatus("Download paused");
    }

    private void resumeDownload() {
        isPaused = false;
        updateNotification("Downloading...",
                (int) ((downloadedBytes * 100) / totalBytes), false);
        updateStatus("Download resumed");
    }

    private void cancelDownload() {
        isCancelled = true;
        isPaused = false;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Download Notifications",
                    NotificationManager.IMPORTANCE_LOW
            );
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification createNotification(String title, int progress, boolean isComplete) {
        RemoteViews notificationLayout = new RemoteViews(getPackageName(),
                R.layout.notification);

        notificationLayout.setTextViewText(R.id.notificationTitle, title);
        notificationLayout.setTextViewText(R.id.notificationText, progress + "%");
        notificationLayout.setProgressBar(R.id.notificationProgress, 100, progress, false);

        if (!isComplete) {
            // Tạo PendingIntent cho nút Pause/Resume
            Intent pauseIntent = new Intent(this, DownloadActionReceiver.class);
            pauseIntent.setAction(isPaused ?
                    "com.example.downloadmanager.ACTION_RESUME" :
                    "com.example.downloadmanager.ACTION_PAUSE");
            PendingIntent pausePendingIntent = PendingIntent.getBroadcast(
                    this, 0, pauseIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            notificationLayout.setTextViewText(R.id.btnPause, isPaused ? "Resume" : "Pause");
            notificationLayout.setOnClickPendingIntent(R.id.btnPause, pausePendingIntent);

            // Tạo PendingIntent cho nút Cancel
            Intent cancelIntent = new Intent(this, DownloadActionReceiver.class);
            cancelIntent.setAction("com.example.downloadmanager.ACTION_CANCEL");
            PendingIntent cancelPendingIntent = PendingIntent.getBroadcast(
                    this, 1, cancelIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            notificationLayout.setOnClickPendingIntent(R.id.btnCancel, cancelPendingIntent);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                .setCustomContentView(notificationLayout)
                .setPriority(NotificationCompat.PRIORITY_LOW);

        return builder.build();
    }

    private void updateNotification(String title, int progress, boolean isComplete) {
        Notification notification = createNotification(title, progress, isComplete);
        notificationManager.notify(NOTIFICATION_ID, notification);
    }

    private void updateStatus(String status) {
        Intent intent = new Intent("DOWNLOAD_STATUS");
        intent.putExtra("status", status);
        sendBroadcast(intent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (downloadThread != null && downloadThread.isAlive()) {
            isCancelled = true;
        }
    }
}